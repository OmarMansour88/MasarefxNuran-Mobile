define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_ee8f69ff5abb41fd8322048793f5255b: function AS_Form_ee8f69ff5abb41fd8322048793f5255b(eventobject) {
        var self = this;
        this.init();
    },
    AS_Form_b8885dd877dd4435ba95083069289394: function AS_Form_b8885dd877dd4435ba95083069289394(eventobject) {
        var self = this;
        this.preShow();
    }
});