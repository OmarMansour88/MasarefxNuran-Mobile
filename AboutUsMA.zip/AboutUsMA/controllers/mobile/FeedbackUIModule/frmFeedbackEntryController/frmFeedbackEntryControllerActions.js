define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_gba1754866d84d9ab4ac5d1125cc648c: function AS_Form_gba1754866d84d9ab4ac5d1125cc648c(eventobject) {
        var self = this;
        kony.application.showLoadingScreen("", "Authenticating the user");
        var authParams = {
            "UserName": "9791697578SB",
            "Password": "Kony@1234",
            "loginOptions": {
                "isOfflineEnabled": false
            }
        };
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");
        authClient.login(authParams, successCallback, errorCallback);

        function successCallback(resSuccess) {
            kony.application.dismissLoadingScreen();
            kony.print(resSuccess);
            var feedbackModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("FeedbackUIModule");
            feedbackModule.presentationController.showFeedBack();
        }

        function errorCallback(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("login is not working...")
        }
    },
});