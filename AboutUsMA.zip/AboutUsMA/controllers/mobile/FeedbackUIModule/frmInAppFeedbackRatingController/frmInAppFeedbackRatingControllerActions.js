define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_fe425fe96fbe400d8af9f3ddb7a990ff: function AS_Form_fe425fe96fbe400d8af9f3ddb7a990ff(eventobject) {
        var self = this;
        this.init();
    },
    AS_Form_he0109c27fb4418ab289a05ebe26d191: function AS_Form_he0109c27fb4418ab289a05ebe26d191(eventobject) {
        var self = this;
        this.preShow();
    }
});