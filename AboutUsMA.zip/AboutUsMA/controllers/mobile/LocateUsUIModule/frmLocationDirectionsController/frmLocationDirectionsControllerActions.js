define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_f6f9fd7d2e344c078db0a7ae30da059e: function AS_Form_f6f9fd7d2e344c078db0a7ae30da059e(eventobject) {
        var self = this;
        this.init();
    },
    AS_Form_ed65cab7cde4448ab5e24d31f2e4e9bf: function AS_Form_ed65cab7cde4448ab5e24d31f2e4e9bf(eventobject) {
        var self = this;
        this.frmLocationPostshow();
    },
    AS_Form_ae418f868c3c483a804be8923c4f6e47: function AS_Form_ae418f868c3c483a804be8923c4f6e47(eventobject) {
        var self = this;
        this.frmLocationPreshow();
    },
    AS_BarButtonItem_j78e7206525648a2b89a6e56adf08a1b: function AS_BarButtonItem_j78e7206525648a2b89a6e56adf08a1b(eventobject) {
        var self = this;
        this.navigateBack();
    }
});