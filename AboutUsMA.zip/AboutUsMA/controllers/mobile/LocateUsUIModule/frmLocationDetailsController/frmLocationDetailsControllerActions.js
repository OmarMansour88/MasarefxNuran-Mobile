define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_bd676377fd5945c68133233e4c2f2289: function AS_Form_bd676377fd5945c68133233e4c2f2289(eventobject) {
        var self = this;
        this.init();
    },
    AS_Form_ha3fad745f9d4715a91986b157705a9a: function AS_Form_ha3fad745f9d4715a91986b157705a9a(eventobject) {
        var self = this;
        this.frmPostShow();
    },
    AS_Form_efb878f944564a6995a7b43a23755ffa: function AS_Form_efb878f944564a6995a7b43a23755ffa(eventobject) {
        var self = this;
        this.frmLocationPreshow();
    },
    AS_BarButtonItem_df1f4258fb5049058bb71a087e5f9c5f: function AS_BarButtonItem_df1f4258fb5049058bb71a087e5f9c5f(eventobject) {
        var self = this;
        this.navigateBack();
    }
});