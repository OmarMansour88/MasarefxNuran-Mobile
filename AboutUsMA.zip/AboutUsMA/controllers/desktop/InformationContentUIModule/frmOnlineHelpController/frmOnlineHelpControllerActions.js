define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmOnlineHelp **/
    AS_Form_abea803ff6bc481a97207deeb97b901d: function AS_Form_abea803ff6bc481a97207deeb97b901d(eventobject) {
        var self = this;
        this.preShow();
    },
    /** onTouchEnd defined for frmOnlineHelp **/
    AS_Form_bcdd23043a504fefa3823205f8287fea: function AS_Form_bcdd23043a504fefa3823205f8287fea(eventobject, x, y) {
        var self = this;
        hidePopups();
    },
    /** postShow defined for frmOnlineHelp **/
    AS_Form_c4f8c3c70e87454aa48521219d5868be: function AS_Form_c4f8c3c70e87454aa48521219d5868be(eventobject) {
        var self = this;
        this.postShow();
    },
    /** onDeviceBack defined for frmOnlineHelp **/
    AS_Form_h11dcaf8ac644af7aaf32597aa3ce815: function AS_Form_h11dcaf8ac644af7aaf32597aa3ce815(eventobject) {
        var self = this;
        kony.print("on device back");
    }
});