define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmCustomerFeedbackSurvey **/
    AS_Form_ac690e6844694c50ad78fdfc95f09c7f: function AS_Form_ac690e6844694c50ad78fdfc95f09c7f(eventobject) {
        var self = this;
        this.preShowCustomerFeedbackSurvey();
    },
    /** postShow defined for frmCustomerFeedbackSurvey **/
    AS_Form_acc658fee64f4e6e885e132742097d23: function AS_Form_acc658fee64f4e6e885e132742097d23(eventobject) {
        var self = this;
        this.postShowCustomerFeedbackSurvey();
    }
});