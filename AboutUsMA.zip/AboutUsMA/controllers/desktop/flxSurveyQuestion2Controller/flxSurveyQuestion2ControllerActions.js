define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxcheckbox4 **/
    AS_FlexContainer_a43cc3055bed436bb0ebc9528a391425: function AS_FlexContainer_a43cc3055bed436bb0ebc9528a391425(eventobject, context) {
        var self = this;
        this.toggleSurveyQuestionNotificationMsgsCheckBox();
    },
    /** onClick defined for flxcheckbox3 **/
    AS_FlexContainer_d49d86a1126c47bf8865df479f65b75f: function AS_FlexContainer_d49d86a1126c47bf8865df479f65b75f(eventobject, context) {
        var self = this;
        this.toggleSurveyQuestionSecuritySettingCheckBox();
    },
    /** onClick defined for flxcheckbox2 **/
    AS_FlexContainer_f6c2289262f04ca68dbd45bba977a1a7: function AS_FlexContainer_f6c2289262f04ca68dbd45bba977a1a7(eventobject, context) {
        var self = this;
        this.toggleSurveyQuestionBillPayCheckBox();
    },
    /** onClick defined for flxcheckbox1 **/
    AS_FlexContainer_g7e5ae4249f2471a88f0572c332b1c1c: function AS_FlexContainer_g7e5ae4249f2471a88f0572c332b1c1c(eventobject, context) {
        var self = this;
        this.toggleSurveyQuestionTransfersCheckBox();
    }
});