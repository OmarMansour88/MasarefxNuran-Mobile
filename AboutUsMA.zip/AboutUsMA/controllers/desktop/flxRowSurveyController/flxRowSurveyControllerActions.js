define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxRating1 **/
    AS_FlexContainer_cbae8b5f173a42118b8a02843fdb4250: function AS_FlexContainer_cbae8b5f173a42118b8a02843fdb4250(eventobject, context) {
        var self = this;
        this.showRatingActionCircle(1);
    },
    /** onClick defined for flxRating3 **/
    AS_FlexContainer_def74d56de1b4fd4879a33ca8888d8c6: function AS_FlexContainer_def74d56de1b4fd4879a33ca8888d8c6(eventobject, context) {
        var self = this;
        this.showRatingActionCircle(3);
    },
    /** onClick defined for flxRating5 **/
    AS_FlexContainer_i998048a32e84f8480142a200291643e: function AS_FlexContainer_i998048a32e84f8480142a200291643e(eventobject, context) {
        var self = this;
        this.showRatingActionCircle(5);
    },
    /** onClick defined for flxRating4 **/
    AS_FlexContainer_ifccee3bf33248fa8128509a30c37b8c: function AS_FlexContainer_ifccee3bf33248fa8128509a30c37b8c(eventobject, context) {
        var self = this;
        this.showRatingActionCircle(4);
    },
    /** onClick defined for flxRating2 **/
    AS_FlexContainer_j0759ae6e39940e1ae16e17684713d2a: function AS_FlexContainer_j0759ae6e39940e1ae16e17684713d2a(eventobject, context) {
        var self = this;
        this.showRatingActionCircle(2);
    }
});