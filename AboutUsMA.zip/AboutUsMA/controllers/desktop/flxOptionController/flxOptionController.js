define({
    //Type your controller code here
});
//this.view.LocateUs.segViewsAndFilters